//package com.example.flowpoc.repository
//
//import com.example.flowpoc.model.ResponseObject
//import com.example.flowpoc.model.ServiceResult
//interface UserRepository {
//
//    suspend fun getDataFromAPI()
//}