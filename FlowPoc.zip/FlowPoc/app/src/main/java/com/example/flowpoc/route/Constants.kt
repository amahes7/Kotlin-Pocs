package com.example.flowpoc.route

sealed class Constants {
    val SUCCESS_STATUS_CODE = "200"

}