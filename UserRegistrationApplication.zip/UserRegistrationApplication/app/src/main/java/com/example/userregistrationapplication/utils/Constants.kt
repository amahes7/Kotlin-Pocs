package com.example.userregistrationapplication.utils

class Constants {

    companion object {
        const val FAILURE_TEXT = "Fail"
        const val SUCCESS_TEXT = "Success"
        const val SUCCESS_MESSAGE = "Api Ran Successfully"
    }
}